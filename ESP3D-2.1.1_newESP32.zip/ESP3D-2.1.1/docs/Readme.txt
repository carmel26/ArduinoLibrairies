Commands.txt list all ESP commands
wconfig.txt list all parameters for SD file config
flash.docx explain how to flash
Files directory contain all files needed by ESP3D
 - index.html.gz // main ui file (mandatory)
 - 404.htm // custom 404 page (optional)
 - favicon.ico //custom browser esp3D icon (optional)
 - macrocfg.json //macro command file (optional)
  